function generateRows(count = 10000){
    const rows = [];
    for(let i = 0; i < count; i++){
        rows.push({
            id: i,
            name: `Name ${i}`,
            email: `email${i}@example.com`
        });
    }
    return rows;
}